#include "stm32f10x.h"                 
#include "Motor.h"
#include "Delay.h"

void Car_Init(){             //С��ģ���ʼ��
	Motor_Init();              //���ģ���ʼ��
}
void Go_Ahead(){             //ǰ��
	Motor_SetLeftSpeed(75);
	Motor_SetRightSpeed(-75);
}
void Go_Back(){              //����
	Motor_SetLeftSpeed(-75);
	Motor_SetRightSpeed(75);
}
void Turn_Left(){            //��ת
	Motor_SetLeftSpeed(0);
	Motor_SetRightSpeed(-75);
}
void Turn_Right(){           //��ת
	Motor_SetRightSpeed(0);
	Motor_SetLeftSpeed(75);
	
}
void Self_Left(){            //����ת
	Motor_SetLeftSpeed(-75);   
	Motor_SetRightSpeed(-75);
}
void Self_Right(){           //����ת
	Motor_SetLeftSpeed(75);     
	Motor_SetRightSpeed(75);
}
void Car_Stop(){             //ֹͣ
	Motor_SetLeftSpeed(0);      
	Motor_SetRightSpeed(0);
}
