#ifndef __CAR_H
#define __CAR_H

void Car_Init(void);
void Self_Right(void);
void Self_Left(void);
void Turn_Right(void);
void Turn_Left(void);
void Go_Back(void);
void Go_Ahead(void);
void Car_Stop(void);

#endif
