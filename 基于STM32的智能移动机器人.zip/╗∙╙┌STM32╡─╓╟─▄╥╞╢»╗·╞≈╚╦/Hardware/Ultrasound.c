#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"
#include "PWM.h"
#include "CAR.h"
#include "Serial.h"
#include "Servo.h"
#include "Ultrasound.h"
#include "Track.h"

uint16_t Cnt;
uint16_t OverCnt;

volatile uint8_t g_exit_flag = 0;     // �˳�ѭ����־
void Ultrasound_Init(){
		
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//trig
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//echo
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	TIM_InternalClockConfig(TIM4);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 60000 - 1;		//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);

}
float Test_Distance(){
	GPIO_SetBits(GPIOB,GPIO_Pin_12);
	Delay_us(20);
	
	
	
	GPIO_ResetBits(GPIOB,GPIO_Pin_12);
	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==RESET){
	};
	TIM_Cmd(TIM4, ENABLE);
	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==SET){
	};
	TIM_Cmd(TIM4, DISABLE);
	Cnt=TIM_GetCounter(TIM4);
	float distance=(Cnt*1.0/10*0.34)/2;
	TIM4->CNT=0;
	Delay_ms(100);
	return distance;
}

// ��Ultrasound.h����������
extern volatile uint8_t g_exit_request;

void obstacleAvoidanceMode()
{
    // �Ƴ��Ǳ�Ҫ���ظ���ʼ��������main�г�ʼ����
    // ֻ����ģʽ���еĳ�ʼ��
    Servo_SetAngle(90);  // ��λ���
    
    while(!g_exit_request)
    {
        Go_Ahead();
        uint16_t a = Test_Distance();
        Serial_SendNumber(a,3);
        
        if(a < 20){
            Car_Stop();
            Servo_SetAngle(0);
            Delay_ms(1000);
            
            uint16_t b = Test_Distance();
            if(b > 20){
                AvoidRight();  // ��װ�ұ��ö���
            }
            else {
                Servo_SetAngle(180);
                Delay_ms(1000);
                uint16_t c = Test_Distance();
                if(c > 20){    
                    AvoidLeft();  // ��װ����ö���
                }
                else{
                    HandleDeadEnd();  // ��װ����ͬ����
                }                
            }
        }
        Delay_ms(100);
    }
    
    // �˳�����
    Car_Stop();
    Servo_SetAngle(90);
    g_exit_request = 0;
}

// ������װ��������Ultrasound.c�ײ���
static void AvoidRight(void)
{
    Servo_SetAngle(90);
    Delay_ms(1000);
    Self_Right();
    Delay_ms(1050);
    if(!g_exit_request) Go_Ahead();
}

static void AvoidLeft(void)
{
    Servo_SetAngle(90);
    Delay_ms(1000);
    Self_Left();
    Delay_ms(1050);
    if(!g_exit_request) Go_Ahead();
}

static void HandleDeadEnd(void)
{
    Servo_SetAngle(90);
    while(!g_exit_request){
        Car_Stop();
        Delay_ms(100);
    }
}
