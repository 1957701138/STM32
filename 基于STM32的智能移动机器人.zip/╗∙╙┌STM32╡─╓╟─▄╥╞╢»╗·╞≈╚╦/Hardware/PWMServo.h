#ifndef __PWMSERVO_H
#define __PWMSERVP_H
void PWM_Init2(void);
void PWM_2SetCompare3(uint16_t Compare);
#endif
