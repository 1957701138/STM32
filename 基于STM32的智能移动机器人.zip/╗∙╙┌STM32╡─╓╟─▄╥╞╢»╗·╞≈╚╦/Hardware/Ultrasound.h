#ifndef __ULTRASOUND_H
#define __ULTRASOUND_H

void Ultrasound_Init(void);

float Test_Distance(void);
void obstacleAvoidanceMode(void);
static void AvoidRight(void);
static void AvoidLeft(void);
static void HandleDeadEnd(void);


#endif
