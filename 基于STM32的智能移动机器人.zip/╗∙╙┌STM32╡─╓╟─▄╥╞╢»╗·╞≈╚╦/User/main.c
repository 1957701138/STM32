#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "PWM.h"
#include "CAR.h"
#include "Serial.h"
#include "Servo.h"
#include "Ultrasound.h"
#include "Track.h"
#include "stdio.h"
// ����ȫ�ֿ��Ʊ���
volatile uint8_t g_system_mode = 0;    // ��ǰϵͳģʽ
volatile uint8_t g_exit_request = 0;   // �˳������־

int main(void)
{  
    // ��ʼ��Ӳ��
    Car_Init();
    Serial_Init();
    Servo_Init();
    Ultrasound_Init();
    Infrared_Init();

    while(1)
    {
        // ��״̬��
        switch(g_system_mode)
        {
            case 0:  // ����ģʽ
                Car_Stop();
                break;
                
            case 0x40:  // ѭ��ģʽ
                trackingMode();
                g_system_mode = 0;  // ���ؿ���
                break;
                
            case 0x41:  // ����ģʽ
                obstacleAvoidanceMode();
                g_system_mode = 0;  // ���ؿ���
                break;
        }
    }
}

// �жϷ������Ż�
void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
    {
        uint16_t Data1 = USART_ReceiveData(USART1);
        
        // ģʽ�л������
        switch(Data1)
        {
            case 0x30:  // ����ֹͣ
                g_exit_request = 1;
                g_system_mode = 0;
                break;
                
            case 0x40:  // ����ѭ��
                g_exit_request = 0;
                g_system_mode = 0x40;
                break;
                
            case 0x41:  // �������
                g_exit_request = 0;
                g_system_mode = 0x41;
                break;
                
            // �����˶������������ִ�У�
            case 0x31: Go_Ahead();          break;
            case 0x32: Go_Back();           break;
			case 0x33: Turn_Left();         break;
            case 0x34: Turn_Right();        break;
			case 0x35: Self_Left();         break;
            case 0x36: Self_Right();        break;
			case 0x37: Servo_SetAngle(0);   break;
			case 0x38: Servo_SetAngle(90);  break;
            case 0x39: Servo_SetAngle(180); break;
            // ... �����˶������ԭ�� ...
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}
