#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"
#include "PWM.h"
#include "CAR.h"
#include "Serial.h"
#include "Servo.h"
#include "Ultrasound.h"
#include "Track.h"
//#include "main.h"

uint16_t Cnt;
uint16_t OverCnt;
void Ultrasound_Init(){
		
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//trig
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//echo
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	TIM_InternalClockConfig(TIM4);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 60000 - 1;		//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);

}
float Test_Distance(){
	GPIO_SetBits(GPIOB,GPIO_Pin_12);
	Delay_us(20);
	
	
	
	GPIO_ResetBits(GPIOB,GPIO_Pin_12);
	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==RESET){
	};
	TIM_Cmd(TIM4, ENABLE);
	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==SET){
	};
	TIM_Cmd(TIM4, DISABLE);
	Cnt=TIM_GetCounter(TIM4);
	float distance=(Cnt*1.0/10*0.34)/2;
	TIM4->CNT=0;
	Delay_ms(100);
	return distance;
}

void obstacleAvoidanceMode()
{
	Car_Init();
	Serial_Init();
	Servo_Init();
	Ultrasound_Init();
	Infrared_Init();

		for (;;)
	{

		Go_Ahead();
		uint16_t a = Test_Distance();
		Serial_SendNumber(a,3);
		if(a<20){
			Car_Stop();
			Servo_SetAngle(0);	Delay_ms(900);
			uint16_t b= Test_Distance();
		
			Serial_SendNumber(b,3);
			if(b>20){
				Servo_SetAngle(90);
				Delay_ms(900);
				Self_Right();
				Delay_ms(900);
				Go_Ahead();
			
			}
			else {
				Servo_SetAngle(180);
				Delay_ms(900);
				uint16_t c= Test_Distance();
				Serial_SendNumber(c,3);
				if(c>20){	
					Servo_SetAngle(90);
					Delay_ms(900);
					Self_Left();
					Delay_ms(900);
					Go_Ahead();
				}else{
					Servo_SetAngle(90);
					
									while(1){};
				}				
			}
		}
		Delay_ms(100);
//		if( *pb == 1)
//		{	
//			break;}

	}
 }
