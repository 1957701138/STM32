#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"
#include "PWM.h"
#include "CAR.h"
#include "Serial.h"
#include "Servo.h"
#include "Ultrasound.h"
#include "Track.h"
#include "stdio.h"
#include "freertos.h"
#include "task.h"
//#include "main.h"



uint16_t Data1;
TaskHandle_t MyTaskHandler;

void (MyTask)( void * arg )
	{
			while(1)
			{

			}
}
int main(void)
{  

	Car_Init();
	Serial_Init();
	Servo_Init();
	Ultrasound_Init();
	Infrared_Init();
	xTaskCreate(MyTask,"MyFreertos",512,NULL,2,&MyTaskHandler);
	vTaskStartScheduler();
 
while(1)
	{	


	 }
}

uint32_t *pb=0;
uint32_t b=0;
void USART1_IRQHandler(void)
{   
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
	{  
		Data1=USART_ReceiveData(USART1);
		
		if(Data1==0x30)b=1;  //ֹͣ
		if(Data1==0x31)b=2;  //ǰ��
		if(Data1==0x32)b=3;  //����
		if(Data1==0x33)b=4;  //��ת
		if(Data1==0x34)b=5;  //��ת
		if(Data1==0x35)b=6;  //����ת
		if(Data1==0x36)b=7;  //����ת
		if(Data1==0x37)b=8;  //���0��
		if(Data1==0x38)b=9;  //���90��
		if(Data1==0x39)b=10;  //���180��
		if(Data1==0x40)b=11;  //ѭ��
		if(Data1==0x41)b=12;  //����
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
	}
	switch(b)					
		{ 
			case 1:{Car_Stop();break;}
			case 2:{Go_Ahead();break;};
			case 3:{Go_Back();break;}
			case 4:{Turn_Left();break;}
			case 5:{Turn_Right();break;}
			case 6:{Self_Left();break;}
			case 7:{Self_Right();break;}
			case 8:{Servo_SetAngle(0);;break;}
			case 9:{Servo_SetAngle(90);break;}
			case 10:{Servo_SetAngle(180);break;}			            
			case 11:{trackingMode(); break;}	
			case 12:{obstacleAvoidanceMode();break;}				
		}

	}
